<div class="templatemo-content">
<img src="bg.png" width="100%"><div id="container">
</div></div>