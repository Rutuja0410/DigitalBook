  <div class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <div class="logo"><h1>Digital Library</h1></div>
      </div>   
    </div>