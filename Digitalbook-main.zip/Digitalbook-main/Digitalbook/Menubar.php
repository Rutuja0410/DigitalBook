      <div class="navbar-collapse collapse templatemo-sidebar">
        <ul class="templatemo-sidebar-menu">
		
		<li><a href="Main.php?page=1">Home</a></li> 
         <li><a href="Main.php?page=2">Add Books</a></li>        
		<li><a href="Main.php?page=3">Books Details</a></li> 

		<li class="sub">
            <a href="javascript:;">
              Books Download Details <div class="pull-right"><span class="caret"></span></div>
            </a>
            <ul class="templatemo-submenu">
		<li><a href="Main.php?page=4">Top Download books</a></li>
		<li><a href="Main.php?page=5">Top Keyword Search</a></li>
            </ul>
         </li>

		<li><a href="Main.php?page=6">Admin Users</a></li> 
         <li><a href="index.php?Logout=Logout" >Sign Out</a></li>
        </ul>
      </div><!--/.navbar-collapse -->